﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EntityLayer;
using BusinessLayer;

namespace UserInterface
{
    public partial class LoginPage : System.Web.UI.Page
    {
        Business bl = new Business();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ImageMap1_Click(object sender, ImageMapEventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            int aid =Convert.ToInt32( txtaid.Text);
            string pswd = txtpswd.Text;

            Admins a = new Admins();
            a.aid = aid;
            a.pswd = pswd;

            var res = bl.checkLogin(a);

            if(res==true)
            {
                Response.Redirect("CalSalPage.aspx");
            }
            else
            {
                lblresult.Text = "incorrect login id or password";
                txtaid.Text = string.Empty;
                txtpswd.Text = string.Empty;
            }
        }
    }
}