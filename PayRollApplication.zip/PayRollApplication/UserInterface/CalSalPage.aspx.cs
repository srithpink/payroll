﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;
using EntityLayer;

namespace UserInterface
{
    public partial class CalSalPage : System.Web.UI.Page
    {
        Business bl = new Business();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label3.Visible = false;
            Label4.Visible = false;
            txtename.Visible = false;
            txthours.Visible = false;
            btncal.Visible = false;
        }

        

        protected void btncal_Click(object sender, EventArgs e)
        {
            int eid = Convert.ToInt32(txteid.Text);
            
            int hrs = Convert.ToInt32(txthours.Text);
            int ba = hrs * 170;
            decimal da =Convert.ToInt64( 0.12 * ba);
            int hra = 150;
            int ta = 120;
            int others = 450;
            decimal pf =Convert.ToInt64( 0.14 * ba);

            decimal netSal = Convert.ToInt64(ba + da + hra + ta + others - pf);
         
            Employee emp = new Employee();
            emp.eid = eid;
            emp.hours = hrs;
            emp.sal = netSal;

            var res = bl.updateSal(emp);

            if (res == "credited")
            {
                lblsalres.Text = "Employee ID: "+emp.eid+"\nSalary is updated as Rs." + emp.sal + " for the total working hours: " + emp.hours;
                txteid.Text = string.Empty;
                txtename.Text = string.Empty;
                txthours.Text = string.Empty;
                txtename.Visible = false;
                txthours.Visible = false;
                Label3.Visible = false;
                Label4.Visible = false;
                btnget.Visible = true;
                txteid.Enabled = true;
            }
            else if (res == "not credited")
            {
                lblsalres.Text = "Error in updating the salary retry";
                txteid.Text = string.Empty;
                txtename.Text = string.Empty;
                txthours.Text = string.Empty;
                txtename.Visible = false;
                Label3.Visible = false;
                Label4.Visible = false;
                txthours.Visible = false;
                txteid.Visible = true;
                btnget.Visible = true;
                btncal.Visible = false;

            }
            else if(res=="updated already")
            {
                lblsalres.Text = "its updated already failed to update again";
                txteid.Enabled = true;
                txteid.Text = string.Empty;
                txtename.Text = string.Empty;
                txthours.Text = string.Empty;
                btnget.Visible = true;
                
            }
            //else if(res=="invalid hours")
            //{
            //    lblsalres.Text = "You have entered invalid hours";
            //    txthours.Text = string.Empty;
            //    txteid.Enabled = false;
            //    txtename.Enabled = false;
            //    txthours.Enabled = true;
            //    btnget.Visible = false;
            //    btncal.Visible = true;
            //}
            else
            {
                lblsalres.Text = "not updated, retry by filling again";
                txteid.Text = string.Empty;
                txtename.Text = string.Empty;
                txthours.Text = string.Empty;
                btnget.Visible = true;
                txteid.Enabled = true;
                txteid.Visible = true;
                
                
            }
        }

        protected void btnget_Click(object sender, EventArgs e)
        {

            int eid = Convert.ToInt32(txteid.Text);
            var res = bl.getname(eid);

            if (res == "null")
            {
                lblsalres.Text = "employee not found";
                btncal.Enabled = false;
                txthours.Enabled = false;
                txtename.Enabled = false;
            }
            else
            {
                txtename.Text = res;
                txtename.Visible = true;
                txteid.Enabled = false;
                txtename.Enabled = false;
                txthours.Visible = true;
                btncal.Visible = true;
                Label3.Visible = true;
                Label4.Visible = true;
                btnget.Visible = false;
                txthours.Enabled = true;
                btncal.Enabled = true;
                lblsalres.Text = string.Empty;
            }
        }
    }
}