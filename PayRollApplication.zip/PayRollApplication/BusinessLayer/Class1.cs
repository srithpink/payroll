﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using DataLayer;

namespace BusinessLayer
{
    public class Business
    {
        Data dl = new Data();
        public bool checkLogin(Admins a)
        {
            if(string.IsNullOrEmpty(a.pswd)||string.IsNullOrWhiteSpace(a.pswd))
            {
                return false;
            }
            else if(string.IsNullOrEmpty(a.aid.ToString())||string.IsNullOrWhiteSpace(a.aid.ToString()))
            {
                return false;
            }
            else
            {
                return dl.checkLogin(a);
            }
            
        }

        public string getname(int eid)
        {
            if (string.IsNullOrEmpty(eid.ToString()) || string.IsNullOrWhiteSpace(eid.ToString()))
            {
                return "null";
            }
            else
            {
                return dl.getname(eid);
            }
        }

        public string updateSal(Employee emp)
        {
           if(string.IsNullOrWhiteSpace(emp.sal.ToString())||string.IsNullOrEmpty(emp.sal.ToString()))
            {
                return "invalid hours";
            }
           else
            {
                return dl.updateSal(emp);
            }
        }
    }
}
