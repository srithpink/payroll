﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class Admins
    {
        public int aid { get; set; }
        public string pswd { get; set; }
    }

    public class Employee
    {
        public int eid { get; set; }
        public string pswd { get; set; }

        public decimal sal { get; set; }
        public string stat { get; set; }

        public int  hours { get; set; }
    }
}
