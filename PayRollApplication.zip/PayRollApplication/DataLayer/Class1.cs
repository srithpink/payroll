﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;

namespace DataLayer
{
    public class Data
    {
        payrollDatabaseEntities db = new payrollDatabaseEntities();
        public bool checkLogin(Admins a)
        {
            try
            {
                var res = db.Admins.Where(x => x.aid == a.aid && x.pswd == a.pswd).SingleOrDefault();
                if(res!=null)
                {
                    return true;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public string getname(int eid)
        {
            try
            {
                var res = db.employees.Where(x => x.eid == eid).SingleOrDefault();
                if(res!=null)
                {
                    return res.ename;
                }
                else
                {
                    return "null";
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public string updateSal(Employee emp)
        {
            try
            {
                var res = db.employees.Where(x => x.eid == emp.eid).SingleOrDefault();
                if(res.statuss=="no")
                {
                    res.salary = emp.sal;
                    res.statuss = "credited";
                    res.eid = emp.eid;
                    
                    var result = db.SaveChanges();
                    if(result>0)
                    {
                        return "credited";
                    }
                    else
                    {
                        return "not credited";
                    }
                }
                else if(res.statuss=="credited")
                {
                    return "updated already";
                }
                else
                {
                    return "no";
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
