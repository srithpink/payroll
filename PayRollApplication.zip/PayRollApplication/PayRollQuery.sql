create database payrollDatabase

use payrollDatabase

create table Admin(
aid int primary key,
pswd varchar(20) not null
)

create table employee(
eid int primary key,
ename varchar(30) not null,
salary money,
statuss varchar(50)
)